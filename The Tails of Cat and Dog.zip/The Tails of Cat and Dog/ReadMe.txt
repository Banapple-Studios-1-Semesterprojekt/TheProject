For at kunne spille spillet bare dobbelt klik på 'CatAndDog.exe'

I denne mappe findes også en video fra gameplayet 'The Tails of Cat and Dog Gameplay.mp4' hvis nu der skulle ske en fejl når man prøver at køre spillet.

Og rapporten kan læses i pdf-filen 'Rapport.pdf'